﻿using MineSweeperConsoleApp.Models.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace MineSweeperConsoleApp.Builders
{
    public interface IBoardBuilder
    {
        IBoard Build(int height, int width);
    }
}
