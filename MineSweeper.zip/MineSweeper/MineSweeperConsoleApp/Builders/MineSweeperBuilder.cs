﻿using MineSweeperConsoleApp.Models.Interface;
using MineSweeperConsoleApp.Models.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace MineSweeperConsoleApp.Builders
{
    public class MineSweeperBuilder : IBoardBuilder
    {
        public IBoard Build(int height, int width)
        {
            return new Board(new Square[width, height]);
        }
    }
}
