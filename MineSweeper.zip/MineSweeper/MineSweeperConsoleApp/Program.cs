﻿using MineSweeperConsoleApp.Builders;
using MineSweeperConsoleApp.Models.Interface;
using System;

namespace MineSweeperConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            BootStrap.Start();
            var builder = BootStrap.Container.GetInstance<IBoardBuilder>();

            IGame game = new Game(builder);
            game.Run();
        }
    }
}
