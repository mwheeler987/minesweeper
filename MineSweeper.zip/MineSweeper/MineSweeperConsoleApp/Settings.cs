﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MineSweeperConsoleApp
{
    public static class Settings
    {
        public const int BOARD_HEIGHT = 8;
        public const int BOARD_WIDTH = 8;
        public const int NUMBER_OF_MINES = 8;
    }
}
