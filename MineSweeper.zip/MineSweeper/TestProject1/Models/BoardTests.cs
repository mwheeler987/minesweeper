﻿using MineSweeperConsoleApp.Models.Interface;
using MineSweeperConsoleApp.Models.Model;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace TestProject1.Models
{
    public class BoardTests
    {
        private IBoard _board = new Board(new Square[8, 8]);

        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

       


        [Test]
        public void Move_MoveUp_CurrentLocationIndexDecreases()
        {
            //arrange
            var initialLocation = _board.GetCurrentLocation();

            //act
            _board.Move('U');
            var currentPosition = _board.GetCurrentLocation().PositionY;
            //assert
            Assert.IsTrue(currentPosition == initialLocation.PositionY - 1);
        }
    }
}
