﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MineSweeperConsoleApp.Builders;
using SimpleInjector;


namespace MineSweeperConsoleApp
{
    public class BootStrap
    {
        public static Container Container;

        public static void Start()
        {
            Container = new Container();

            Container.Register<IBoardBuilder, MineSweeperBuilder>(Lifestyle.Singleton);

            Container.Verify();
        }
    }
}
