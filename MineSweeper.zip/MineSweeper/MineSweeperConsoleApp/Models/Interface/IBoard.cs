﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MineSweeperConsoleApp.Models.Interface
{
    public interface IBoard
    {

        ISquare[,] Squares { get; set; }
        ISquare GetCurrentLocation();
        void Draw();
        bool Move(char direction);
    }
}
