﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MineSweeperConsoleApp.Models.Interface
{
    public interface IGame
    {
        bool Finished { get; }
        int MineCount { get; set; }

        void Run();
    }
}
